/**
 * \file AnimShiftChannel.cpp
 *
 * \author Mark Maroki
 */

#include "stdafx.h"
#include "AnimShiftChannel.h"


/**
 * Constructor
 */
CAnimShiftChannel::CAnimShiftChannel()
{
}


/**
 * Destuctor
 */
CAnimShiftChannel::~CAnimShiftChannel()
{
}

/**
 * Setting the Keyframe
 * \param mPoint 
 */
void CAnimShiftChannel::SetKeyFrame(Point mPoint)
{

	//// Create a keyframe of the appropriate type
	//// Telling it this channel and the angle
	//shared_ptr<KeyframePlacement> keyframe =
	//	make_shared<KeyframePlacement>(this, angle);

	//// Insert it into the collection
	//InsertKeyframe(keyframe);

}
