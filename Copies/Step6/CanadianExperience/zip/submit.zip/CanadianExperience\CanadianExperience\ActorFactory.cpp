/**
 * \file ActorFactory.cpp
 *
 * \author Mark Maroki
 */

#include "stdafx.h"
#include "ActorFactory.h"


/**
 * Constructor
 */
CActorFactory::CActorFactory()
{
}


/**
 * Destructor
 */
CActorFactory::~CActorFactory()
{
}
