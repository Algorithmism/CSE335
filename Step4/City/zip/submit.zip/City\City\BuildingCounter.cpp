/**
 * \file BuildingCounter.cpp
 * Class That tests building counter
 * \author Mark Maroki
 */


#include "stdafx.h"
#include "BuildingCounter.h"


/**
 * Constructor
 */
CBuildingCounter::CBuildingCounter()
{
}


/**
 * Destructor
 */
CBuildingCounter::~CBuildingCounter()
{
}
