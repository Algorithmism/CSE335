/**
 * \file FansVisitor.cpp
 *	Fans visitor class
 * \author Mark Maroki
 */



#include "stdafx.h"
#include "FansVisitor.h"
#include "TileFans.h"

CFansVisitor::CFansVisitor()
{
}


CFansVisitor::~CFansVisitor()
{
}

void CFansVisitor::VisitFans(CTileFans * fans)
{
	fans->downState();

}

