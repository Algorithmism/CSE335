/**
 * \file TileVisitor.cpp
 * Visitor Tile 
 * \author Mark Maroki
 */



#include "stdafx.h"
#include "TileVisitor.h"


CTileVisitor::CTileVisitor()
{
}


CTileVisitor::~CTileVisitor()
{
}
