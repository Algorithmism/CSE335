/**
 * \file Controller.cpp
 *
 * \author Mark Maroki
 */

#include "stdafx.h"
#include <cassert>
#include "Controller.h"


 /// The time the door remains open
const double DoorOpenTime = 2.0;

/**
 * Constructor
 */
CController::CController()
{
	for (int f = 1; f <= NumFloors; f++)
	{
		mFloors[f - 1].SetController(this);
		mFloors[f - 1].SetFloor(f);
	}
}


/**
 * Destructor
 */
CController::~CController()
{

}

/** This function is called when the open button is pressed.
 */
void CController::OnOpenPressed()
{
	switch (mState)
	{
	case Idle:
		// Transition to the DoorOpening state
		SetState(DoorOpening);
		break;

	case DoorOpen:
		SetState(DoorOpen);
		break;

	case DoorClosing:
		SetState(DoorOpening);
		break;

	default:
		break;
	}
}


/**
 * Panel Floor Pressed
 * \param floor 
 */
void CController::OnPanelFloorPressed(int floor)
{
	mFloors[floor - 1].SetPanel(true);
}

/** This function is called when the up button is pressed
 * on a floor.
 * \param floor The floor we are called to 1-3
 */
void CController::OnCallUpPressed(int floor)
{
	mFloors[floor - 1].SetUp(true);
}

/**
 * On call down pressed
 * \param floor 
 */
void CController::OnCallDownPressed(int floor)
{
	mFloors[floor - 1].SetDown(true);
}

/**
 * Determine the floor to go to.
 *
 * Given the current direction we are going, determine what floor
 * we should go to.
 * \returns A floor to go to (1 to 3) or 0 if none
 */
int CController::WhatFloorToGoTo()
{
	if (mGoingUp)
	{
		// We are going up, so try for a floor in that direction
		int floor = WhatFloorUp();
		if (floor != 0)
			return floor;

		// Guess we can't go up, so see if we need to go down
		floor = WhatFloorDown();
		if (floor != 0)
		{
			// Reverse the direction
			mGoingUp = false;
			return floor;
		}
	}
	else
	{
		//just flip the process
		// We are going up, so try for a floor in that direction
		int floor = WhatFloorDown();
		if (floor != 0)
			return floor;

		// Guess we can't go down, so see if we need to go up
		floor = WhatFloorUp();
		if (floor != NumFloors)
		{
			// Reverse the direction
			mGoingUp = true;
			return floor;
		}

	}

	return 0;
}

/**
* Determine floor to go to in the up direction.
*
* Assuming we are going up, determine any floor we would
* go to in the up direction.
* \returns Floor 1 to 3 or 0 if no floor is selected.
*/
int CController::WhatFloorUp()
{
	// What floor are we currently on?
	// We stop with FloorTolerance of a floor. Suppose I am at position
	// 3.42. That's just above 3.42 - 3.28 = 0.14 above floor 2, but 
	// it's within the tolerance, so we think of it as on floor 2.
	int floor = int((GetPosition() + FloorTolerance) / FloorSpacing) + 1;

	// Is there a floor to goto in the up direction that has the panel
	// or the up button pressed?
	for (int f = floor; f <= NumFloors; f++)
	{
		if (mFloors[f - 1].GetUp() || mFloors[f - 1].GetPanel())
			return f;
	}

	// Is there a floor to go to in the up direction that has the down
	// button pressed. We don't look at the current floor, though.
	for (int f = NumFloors; f > floor; f--)
	{
		if (mFloors[f - 1].GetDown())
			return f;
	}

	// If nothing, return 0;
	return 0;
}

/**
 * What floor down
 * \returns 
 */
int CController::WhatFloorDown()
{
	// What floor are we currently on?
	// We stop with FloorTolerance of a floor. Suppose I am at position
	// 3.42. That's just above 3.42 - 3.28 = 0.14 above floor 2, but 
	// it's within the tolerance, so we think of it as on floor 2.
	int floor = int((GetPosition() + FloorTolerance) / FloorSpacing) + 1; ///< This will be the same

	// Is there a floor to goto in the down direction that has the panel
	// or the down button pressed?
	for (int f = floor; f < NumFloors; f++)
	{
		if (mFloors[f - 1].GetDown() || mFloors[f - 1].GetPanel())
			return f;
	}

	for (int f = floor; f > 0; f--)
	{
		if (mFloors[f - 1].GetDown() || mFloors[f - 1].GetPanel())
			return f;
	}

	// Is there a floor to go to in the down direction that has the up
	// button pressed. We don't look at the current floor, though.
	for (int f = NumFloors; f > 0; f--)
	{
		if (mFloors[f - 1].GetUp()) ///<reverse the process from the one given by Dr. Owen
			return f;
	}

	// If nothing, return 0;
	return 0;
}

/**
 * \brief Sets the States
 * \param state 
 */
void CController::SetState(States state)
{
	mState = state;
	mStateTime = 0;

	// Entry activities for states
	switch (mState)
	{
	case Idle:
		SetDoorMotor(mFloor, 0);
		break;

	case DoorOpening:
		SetDoorMotor(mFloor, 1);
		WhatFloorToGoTo();
		mFloors[mFloor - 1].SetPanel(false);
		if (mGoingUp)
		{
			mFloors[mFloor - 1].SetUp(false);
		}
		else
		{
			mFloors[mFloor - 1].SetDown(false);
		}
		break;

	case DoorOpen:
		SetDoorMotor(mFloor, 0);
		break;

	case DoorClosing:
		SetDoorMotor(mFloor, -1);
		break;

    case Moving:
        SetBrake(false);
        SetMotorSpeed(mGoingUp ? 1 : -1);
        break;
	case Stop:
		SetMotorSpeed(0);
		SetBrake(true);
		break;

	default:
		break;
	}
}

/** Elevator service function
 *
 * This function is called once every 0.001 seconds and
 * allows us to control elevator functionality.
 */
void CController::Service()
{
	// Increment state time by 1 millisecond
	mStateTime += 0.001;
	switch (mState)
	{
	case Idle:
	{
		int floor = WhatFloorToGoTo();
		if (floor == mFloor)
		{
			// Button pressed on this floor. Open the door
			SetState(DoorOpening);
		}

		else if (floor != 0)
		{
			SetState(Moving);
		}
	}
	break;


	case DoorOpen:
		if (mStateTime >= DoorOpenTime)
		{
			SetState(DoorClosing);
		}
		break;

	case DoorClosing:
		if (IsDoorClosed(mFloor))
		{
			SetState(Idle);
		}
		break;
	
	case DoorOpening:
		if (IsDoorOpen(mFloor))
		{
			SetState(DoorOpen);
		}
		break;

	case Moving:
	{
		int floor = WhatFloorToGoTo();
		assert(floor != 0);

		// What's the position for that floor?
		double floorPosition = (floor - 1) * FloorSpacing;
		if (fabs(GetPosition() - floorPosition) < FloorTolerance)
		{
			mFloor = floor;
			SetState(Stop);
		}
	}
	break;

	case Stop:
		if (mStateTime >= 1)
		{
			SetState(DoorOpening);
		}

	
	default:
		break;
	}
}

/** This function is called when the door close button is pressed.
 */
void CController::OnClosePressed()
{
	switch (mState)
	{
	case DoorOpen:
		SetState(DoorClosing);
		break;

	case DoorOpening:
		SetState(DoorClosing);
		break;

	default:
		break;
	}
}
